// Common JS

function openCustom(link) {
    window.open(link);
}

// openExploreWebPage

function openExploreWebPage() {
    window.open('/web/web.html')
}

function openExpWebPage(link) {
    window.open(link)
}